CloverETL JavaExamples
===========================

This project contains illustration classes for embedding CloverETL to java application.

To run any of the examples cloveretl.engine.jar and 3rd part libraries (see cloverETL/readme.txt) need to be set on classpath. 
Some examples require additional plugins library set on the classpath (see description of each example).

To run some examples successfully, CloverETL plugins directory must be provided. It can be set as program argument, when running 
particular example or it can be set for all examples together in params.txt file. This file defines some other properties also. 
All the parameters can be provided as program arguments as well, when running actual example.